package businesscomponents;

import org.openqa.selenium.*;

import supportlibraries.ReusableLibrary;
import supportlibraries.ScriptHelper;

import com.cognizant.framework.Status;


/**
 * Functional Components class
 * @author Cognizant
 */
public class FunctionalComponents extends ReusableLibrary
{
	/**
	 * Constructor to initialize the component library
	 * @param scriptHelper The {@link ScriptHelper} object passed from the {@link DriverScript}
	 */
	public FunctionalComponents(ScriptHelper scriptHelper)
	{
		super(scriptHelper);
	}
	
	public void invokeApplication()
	{
		driver.get(properties.getProperty("ApplicationUrl"));
		report.updateTestLog("Invoke Application", "Invoke the application under test @ " +
								properties.getProperty("ApplicationUrl"), Status.DONE);
	}
	
	public void login()
	{
		String userName = dataTable.getData("General_Data", "Username");
		String password = dataTable.getData("General_Data", "Password");
		
		driver.findElement(By.name("userName")).sendKeys(userName);
		driver.findElement(By.name("password")).sendKeys(password);
		driver.findElement(By.name("login")).click();
		
		report.updateTestLog("Login", "Enter login credentials: " +
										"Username = " + userName + ", " +
										"Password = " + password, Status.DONE);
	}
	
	public void registerUser()
	{
		driver.findElement(By.linkText("REGISTER")).click();
		driver.findElement(By.name("firstName")).sendKeys(dataTable.getData("RegisterUser_Data", "FirstName"));
		driver.findElement(By.name("lastName")).sendKeys(dataTable.getData("RegisterUser_Data", "LastName"));		
		driver.findElement(By.name("phone")).sendKeys(dataTable.getData("RegisterUser_Data", "Phone"));		
		driver.findElement(By.name("userName")).sendKeys(dataTable.getData("RegisterUser_Data", "Email"));	
		driver.findElement(By.name("address1")).sendKeys(dataTable.getData("RegisterUser_Data", "Address"));
		driver.findElement(By.name("city")).sendKeys(dataTable.getData("RegisterUser_Data", "City"));
		driver.findElement(By.name("state")).sendKeys(dataTable.getData("RegisterUser_Data", "State"));
		driver.findElement(By.name("postalCode")).sendKeys(dataTable.getData("RegisterUser_Data", "PostalCode"));
		driver.findElement(By.name("email")).sendKeys(dataTable.getData("General_Data", "Username"));
		String password = dataTable.getData("General_Data", "Password");
		driver.findElement(By.name("password")).sendKeys(password);
		driver.findElement(By.name("confirmPassword")).sendKeys(password);
		driver.findElement(By.name("register")).click();
		report.updateTestLog("Registration", "Enter user details for registration", Status.DONE);
	}
	
	public void clickSignIn()
	{
		driver.findElement(By.linkText("sign-in")).click();
		report.updateTestLog("Click sign-in", "Click the sign-in link", Status.DONE);
	}
	
	public void findFlights()
	{
		driver.findElement(By.name("passCount")).sendKeys((dataTable.getData("Passenger_Data", "PassengerCount")));
		driver.findElement(By.name("fromPort")).sendKeys((dataTable.getData("Flights_Data", "FromPort")));
		driver.findElement(By.name("fromMonth")).sendKeys((dataTable.getData("Flights_Data", "FromMonth")));
		driver.findElement(By.name("fromDay")).sendKeys((dataTable.getData("Flights_Data", "FromDay")));
		driver.findElement(By.name("toPort")).sendKeys((dataTable.getData("Flights_Data", "ToPort")));
		driver.findElement(By.name("toMonth")).sendKeys((dataTable.getData("Flights_Data", "ToMonth")));
		driver.findElement(By.name("toDay")).sendKeys((dataTable.getData("Flights_Data", "ToDay")));
		driver.findElement(By.name("airline")).sendKeys((dataTable.getData("Flights_Data", "Airline")));
		driver.findElement(By.name("findFlights")).click();
		report.updateTestLog("Find Flights", "Search for flights using given test data", Status.DONE);
	}
	
	public void selectFlights()
	{
		driver.findElement(By.name("reserveFlights")).click();
		report.updateTestLog("Select Flights", "Select the first available flights", Status.DONE);
	}
	
	public void bookFlights()
	{
		String[] passengerFirstNames = dataTable.getData("Passenger_Data", "PassengerFirstNames").split(",");
		String[] passengerLastNames = dataTable.getData("Passenger_Data", "PassengerLastNames").split(",");
		int passengerCount = Integer.parseInt(dataTable.getData("Passenger_Data", "PassengerCount"));
		
		for(int i=0; i<passengerCount; i++) {
			driver.findElement(By.name("passFirst" + i)).sendKeys(passengerFirstNames[i]);
			driver.findElement(By.name("passLast" + i)).sendKeys(passengerLastNames[i]);
		}
		driver.findElement(By.name("creditCard")).sendKeys(dataTable.getData("Passenger_Data", "CreditCard"));
		driver.findElement(By.name("creditnumber")).sendKeys(dataTable.getData("Passenger_Data", "CreditNumber"));
		
		report.updateTestLog("Book Tickets", "Enter passenger details and book tickets", Status.SCREENSHOT);
		
		driver.findElement(By.name("buyFlights")).click();
	}
	
	public void backToFlights()
	{
		driver.findElement(By.xpath("//a/img")).click();
	}
	
	public void logout()
	{
		driver.findElement(By.linkText("SIGN-OFF")).click();
		report.updateTestLog("Logout", "Click the sign-off link", Status.DONE);
	}
}